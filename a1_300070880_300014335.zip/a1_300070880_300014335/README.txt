Student name: Nick Bailuc, Illia Negovora
Student number: 300014335, 300070880
Course code: ITI1121
Lab section: C-02, C-01

This file is part of an archive, of a Java implementation of Tic-Tac-Toe. The archive contains:
-README.txt (this file)
-StudentInfo.java
-TicTacToe.java
-TicTacToeGame.java
-CellValue.java
-GameState.java
